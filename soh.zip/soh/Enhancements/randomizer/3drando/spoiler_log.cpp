#include "spoiler_log.hpp"

#include "../dungeon.h"
#include "../static_data.h"
#include "../settings.h"
#include "../entrance.h"
#include "../trial.h"
#include "pool_functions.hpp"
#include "soh/Enhancements/randomizer/randomizer_entrance_tracker.h"
#include <nlohmann/json.hpp>
#include <spdlog/spdlog.h>

#include <cstdio>
#include <cstring>
#include <map>
#include <string>
#include <sstream>
#include <vector>
#include <iostream>
#include <fstream>
#include <filesystem>
#include <variables.h>

#include <ship/Context.h>

#include <libultraship/bridge/consolevariablebridge.h>

using json = nlohmann::ordered_json;
using namespace Rando;

json jsonData;
std::map<RandomizerHintTextKey, Rando::ItemLocation*> hintedLocations;

extern std::array<std::string, 17> hintCategoryNames;
extern Region* GetHintRegion(uint32_t);

namespace {
std::string placementtxt;
} // namespace

void GenerateHash() {
    auto ctx = Rando::Context::GetInstance();
    std::string hash = ctx->GetHash();
    // adds leading 0s to the hash string if it has less than 10 digits.
    while (hash.length() < 10) {
        hash = "0" + hash;
    }
    for (size_t i = 0, j = 0; i < ctx->hashIconIndexes.size(); i++, j += 2) {
        int number = std::stoi(hash.substr(j, 2));
        ctx->hashIconIndexes[i] = number;
    }
}

static auto GetGeneralPath() {
    return "./randomizer/haha.xml";
}

static auto GetSpoilerLogPath() {
    return GetGeneralPath();
}

static auto GetPlacementLogPath() {
    return GetGeneralPath();
}

// Writes the location to the specified node.
static void WriteLocation(std::string sphere, const RandomizerCheck locationKey, const bool withPadding = false) {
    Rando::Location* location = Rando::StaticData::GetLocation(locationKey);
    Rando::ItemLocation* itemLocation = Rando::Context::GetInstance()->GetItemLocation(locationKey);

    switch (gSaveContext.language) {
        case LANGUAGE_ENG:
        default:
            jsonData["playthrough"][sphere][location->GetName()] = itemLocation->GetPlacedItemName().GetEnglish();
            break;
        case LANGUAGE_GER:
            jsonData["playthrough"][sphere][location->GetName()] = itemLocation->GetPlacedItemName().GetGerman();
            break;
        case LANGUAGE_FRA:
            jsonData["playthrough"][sphere][location->GetName()] = itemLocation->GetPlacedItemName().GetFrench();
            break;
    }
}

// Writes a shuffled entrance to the specified node
static void WriteShuffledEntrance(std::string sphereString, Entrance* entrance) {
    int16_t originalIndex = entrance->GetIndex();
    int16_t destinationIndex = -1;
    int16_t replacementIndex = entrance->GetReplacement()->GetIndex();
    int16_t replacementDestinationIndex = -1;
    const EntranceData* sourceData = EntranceTracker::GetEntranceData(originalIndex);
    const EntranceData* destinationData = EntranceTracker::GetEntranceData(replacementIndex);
    if (sourceData == nullptr || destinationData == nullptr) {
        SPDLOG_ERROR("WriteShuffledEntrance: missing entrance data for index {} (override {})", originalIndex,
                     replacementIndex);
        assert(false);
        return;
    }
    std::string name = sourceData->source;
    std::string text = destinationData->destination;

    // Track the reverse destination, useful for savewarp handling
    if (entrance->GetReverse() != nullptr) {
        destinationIndex = entrance->GetReverse()->GetIndex();
        // When decouple is off we track the replacement's reverse destination, useful for recording visited entrances
        if (!entrance->IsDecoupled()) {
            replacementDestinationIndex = entrance->GetReplacement()->GetReverse()->GetIndex();
        }
    }

    json entranceJson = json::object({
        { "type", entrance->GetType() },
        { "index", originalIndex },
        { "destination", destinationIndex },
        { "override", replacementIndex },
        { "overrideDestination", replacementDestinationIndex },
    });

    jsonData["entrances"].push_back(entranceJson);

    // When decoupled entrances is off, handle saving reverse entrances
    if (entrance->GetReverse() != nullptr && !entrance->IsDecoupled()) {
        json reverseEntranceJson = json::object({
            { "type", entrance->GetReverse()->GetType() },
            { "index", replacementDestinationIndex },
            { "destination", replacementIndex },
            { "override", destinationIndex },
            { "overrideDestination", originalIndex },
        });

        jsonData["entrances"].push_back(reverseEntranceJson);
    }

    switch (gSaveContext.language) {
        case LANGUAGE_ENG:
        case LANGUAGE_GER:
        case LANGUAGE_FRA:
        default:
            jsonData["entrancesMap"][sphereString][name] = text;
            break;
    }
}

// Writes the settings (without excluded locations, starting inventory and tricks) to the spoilerLog document.
static void WriteSettings() {
    auto ctx = Rando::Context::GetInstance();
    std::array<Rando::Option, RSK_MAX> options = Rando::Settings::GetInstance()->GetAllOptions();
    for (const Rando::Option& option : options) {
        // skip unassigned settings (RSK_NONE)
        if (option.GetOptionCount() > 0) {
            jsonData["settings"][option.GetName()] = option.GetOptionText(ctx->GetOption(option.GetKey()).Get());
        }
    }
}

// Removes any line breaks from s.
std::string RemoveLineBreaks(std::string s) {
    s.erase(std::remove(s.begin(), s.end(), '\n'), s.end());
    return s;
}

// Writes the excluded locations to the spoiler log, if there are any.
static void WriteExcludedLocations() {
    auto ctx = Rando::Context::GetInstance();

    for (const auto& areaOptions : Rando::Settings::GetInstance()->GetExcludeLocationsOptions()) {
        for (const auto* location : areaOptions) {
            if (ctx->GetLocationOption(static_cast<RandomizerCheck>(location->GetKey())).Get() == RO_LOCATION_INCLUDE) {
                continue;
            }

            jsonData["excludedLocations"].push_back(RemoveLineBreaks(location->GetName()));
        }
    }
}

// Writes the starting inventory to the spoiler log, if there is any.
static void WriteStartingInventory() {
    auto ctx = Rando::Context::GetInstance();
    const Rando::OptionGroup& optionGroup = Rando::Settings::GetInstance()->GetOptionGroup(RSG_STARTING_INVENTORY);
    for (const Rando::OptionGroup* subGroup : optionGroup.GetSubGroups()) {
        if (subGroup->GetContainsType() == Rando::OptionGroupType::DEFAULT) {
            for (Rando::Option* option : subGroup->GetOptions()) {
                jsonData["settings"][option->GetName()] = option->GetOptionText(ctx->GetOption(option->GetKey()).Get());
            }
        }
    }
}

// Writes the enabled tricks to the spoiler log, if there are any.
static void WriteEnabledTricks() {
    auto ctx = Rando::Context::GetInstance();

    for (const auto& setting : Rando::Settings::GetInstance()->GetOptionGroup(RSG_TRICKS).GetOptions()) {
        if (ctx->GetTrickOption(static_cast<RandomizerTrick>(setting->GetKey())).IsNot(RO_GENERIC_ON)) {
            continue;
        }
        jsonData["enabledTricks"].push_back(RemoveLineBreaks(setting->GetName()).c_str());
    }
}

// Writes the Master Quest dungeons to the spoiler log, if there are any.
static void WriteMasterQuestDungeons() {
    auto ctx = Rando::Context::GetInstance();
    for (const auto* dungeon : ctx->GetDungeons()->GetDungeonList()) {
        std::string dungeonName;
        if (dungeon->IsVanilla()) {
            continue;
        }
        jsonData["masterQuestDungeons"].push_back(dungeon->GetName());
    }
}

// Writes the required trials to the spoiler log, if there are any.
static void WriteChosenOptions() {
    auto ctx = Rando::Context::GetInstance();
    for (const auto& trial : ctx->GetTrials()->GetTrialList()) {
        if (trial->IsRequired()) {
            std::string trialName = trial->GetName().GetForCurrentLanguage(MF_CLEAN);
            jsonData["requiredTrials"].push_back(RemoveLineBreaks(trialName));
        }
    }
    if (ctx->GetOption(RSK_SELECTED_STARTING_AGE).Is(RO_AGE_ADULT)) {
        jsonData["SelectedStartingAge"] = "Adult";
    } else {
        jsonData["SelectedStartingAge"] = "Child";
    }
}

// Writes the intended playthrough to the spoiler log, separated into spheres.
static void WritePlaythrough() {
    auto ctx = Rando::Context::GetInstance();

    for (size_t i = 0; i < ctx->playthroughLocations.size(); i++) {
        std::string sphereString = spdlog::fmt_lib::format("sphere {:0>2}", i);
        for (const RandomizerCheck key : ctx->playthroughLocations[i]) {
            if (!ctx->GetItemLocation(key)->IsHidden()) {
                WriteLocation(sphereString, key, true);
            }
        }
    }
}

// Write the randomized entrance playthrough to the spoiler log, if applicable
static void WriteShuffledEntrances() {
    auto ctx = Rando::Context::GetInstance();
    for (size_t i = 0; i < ctx->GetEntranceShuffler()->playthroughEntrances.size(); i++) {
        std::string sphereString = spdlog::fmt_lib::format("sphere {:0>2}", i);
        for (Entrance* entrance : ctx->GetEntranceShuffler()->playthroughEntrances[i]) {
            WriteShuffledEntrance(sphereString, entrance);
        }
    }
}

Rando::ItemLocation* GetItemLocation(RandomizerGet item) {
    auto ctx = Rando::Context::GetInstance();
    return ctx->GetItemLocation(FilterFromPool(ctx->allLocations, [item, ctx](const RandomizerCheck loc) {
        return ctx->GetItemLocation(loc)->GetPlacedRandomizerGet() == item;
    })[0]);
}

static void WriteAllLocations() {
    auto ctx = Rando::Context::GetInstance();
    for (const RandomizerCheck key : ctx->allLocations) {
        Rando::ItemLocation* location = ctx->GetItemLocation(key);
        std::string placedItemName;

        switch (gSaveContext.language) {
            case 0:
            default:
                placedItemName = location->GetPlacedItemName().GetEnglish();
                break;
            case 1:
                placedItemName = location->GetPlacedItemName().GetGerman();
                break;
            case 2:
                placedItemName = location->GetPlacedItemName().GetFrench();
                break;
        }

        // If it's a simple item (not an ice trap, doesn't have a price)
        // just add the name of the item and move on
        if (!location->HasCustomPrice() && location->GetPlacedRandomizerGet() != RG_ICE_TRAP) {

            jsonData["locations"][Rando::StaticData::GetLocation(location->GetRandomizerCheck())->GetName()] =
                placedItemName;
            continue;
        }

        // We're dealing with a complex item, build out the json object for it
        jsonData["locations"][Rando::StaticData::GetLocation(location->GetRandomizerCheck())->GetName()]["item"] =
            placedItemName;

        if (location->HasCustomPrice()) {
            jsonData["locations"][Rando::StaticData::GetLocation(location->GetRandomizerCheck())->GetName()]["price"] =
                location->GetPrice();
        }
        if (location->IsAHintAccessible()) {
            hintedLocations.emplace(Rando::StaticData::GetLocation(key)->GetHintKey(), location);
        }

        if (location->GetPlacedRandomizerGet() == RG_ICE_TRAP) {
            switch (gSaveContext.language) {
                case 0:
                default:
                    jsonData["locations"][Rando::StaticData::GetLocation(location->GetRandomizerCheck())->GetName()]
                            ["model"] = Rando::StaticData::RetrieveItem(
                                            ctx->overrides[location->GetRandomizerCheck()].LooksLike())
                                            .GetName()
                                            .GetEnglish();
                    jsonData["locations"][Rando::StaticData::GetLocation(location->GetRandomizerCheck())->GetName()]
                            ["trickName"] = ctx->overrides[location->GetRandomizerCheck()].GetTrickName().GetEnglish();
                    jsonData["locations"][Rando::StaticData::GetLocation(location->GetRandomizerCheck())->GetName()]
                            ["trickArticle"] =
                                ctx->overrides[location->GetRandomizerCheck()].GetTrickArticle().GetEnglish();
                    break;
                case 1:
                    jsonData["locations"][Rando::StaticData::GetLocation(location->GetRandomizerCheck())->GetName()]
                            ["model"] = Rando::StaticData::RetrieveItem(
                                            ctx->overrides[location->GetRandomizerCheck()].LooksLike())
                                            .GetName()
                                            .GetGerman();
                    jsonData["locations"][Rando::StaticData::GetLocation(location->GetRandomizerCheck())->GetName()]
                            ["trickName"] = ctx->overrides[location->GetRandomizerCheck()].GetTrickName().GetGerman();
                    jsonData["locations"][Rando::StaticData::GetLocation(location->GetRandomizerCheck())->GetName()]
                            ["trickArticle"] =
                                ctx->overrides[location->GetRandomizerCheck()].GetTrickArticle().GetGerman();
                    break;
                case 2:
                    jsonData["locations"][Rando::StaticData::GetLocation(location->GetRandomizerCheck())->GetName()]
                            ["model"] = Rando::StaticData::RetrieveItem(
                                            ctx->overrides[location->GetRandomizerCheck()].LooksLike())
                                            .GetName()
                                            .GetFrench();
                    jsonData["locations"][Rando::StaticData::GetLocation(location->GetRandomizerCheck())->GetName()]
                            ["trickName"] = ctx->overrides[location->GetRandomizerCheck()].GetTrickName().GetFrench();
                    jsonData["locations"][Rando::StaticData::GetLocation(location->GetRandomizerCheck())->GetName()]
                            ["trickArticle"] =
                                ctx->overrides[location->GetRandomizerCheck()].GetTrickArticle().GetFrench();
                    break;
            }
        }
    }
}

void SpoilerLog_Write() {
    auto ctx = Rando::Context::GetInstance();

    jsonData.clear();

    jsonData["version"] = (char*)gBuildVersion;
    jsonData["fileType"] = FILE_TYPE_SPOILER;
    jsonData["git_branch"] = (char*)gGitBranch;
    jsonData["git_commit"] = (char*)gGitCommitHash;
    jsonData["seed"] = ctx->GetSeedString();
    jsonData["finalSeed"] = ctx->GetSeed();

    // Write Hash
    int index = 0;
    for (uint8_t seed_value : ctx->hashIconIndexes) {
        jsonData["file_hash"][index] = seed_value;
        index++;
    }

    WriteSettings();
    WriteExcludedLocations();
    WriteStartingInventory();
    WriteEnabledTricks();
    WriteMasterQuestDungeons();
    WriteChosenOptions();
    WritePlaythrough();

    ctx->playthroughLocations.clear();
    ctx->playthroughBeatable = false;

    ctx->WriteHintJson(jsonData);
    WriteShuffledEntrances();
    WriteAllLocations();

    if (!std::filesystem::exists(Ship::Context::GetPathRelativeToAppDirectory("Randomizer"))) {
        std::filesystem::create_directory(Ship::Context::GetPathRelativeToAppDirectory("Randomizer"));
    }

    std::string jsonString = jsonData.dump(4);
    std::ostringstream fileNameStream;
    for (uint8_t i = 0; i < ctx->hashIconIndexes.size(); i++) {
        if (i) {
            fileNameStream << '-';
        }
        if (ctx->hashIconIndexes[i] < 10) {
            fileNameStream << '0';
        }
        fileNameStream << std::to_string(ctx->hashIconIndexes[i]);
    }
    std::string fileName = fileNameStream.str();
    std::ofstream jsonFile(Ship::Context::GetPathRelativeToAppDirectory(
        (std::string("Randomizer/") + fileName + std::string(".json")).c_str()));
    jsonFile << std::setw(4) << jsonString << std::endl;
    jsonFile.close();

    CVarSetString(CVAR_GENERAL("SpoilerLog"), (std::string("./Randomizer/") + fileName + std::string(".json")).c_str());
}

void PlacementLog_Msg(std::string_view msg) {
    placementtxt += msg;
}

void PlacementLog_Clear() {
    placementtxt = "";
}
