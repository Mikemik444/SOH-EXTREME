#pragma once

#include <array>
#include <map>
#include <set>
#include <unordered_map>
#include "randomizerTypes.h"
#include "item.h"
#include "item_location.h"
#include "location.h"

namespace Rando {

/**
 * @brief Singleton for storing and accessing static Randomizer-related data
 *
 * The StaticData class is a class for storing and accessing static Randomizer-related data.
 * Static Data, in this context, refers to data that is the same for every single randomizer seed,
 * i.e. the item and location tables. This class is intended to be used as a Singleton.
 */
class StaticData {
  private:
    static std::array<Item, RG_MAX> itemTable;
    static std::array<Location, RC_MAX> locationTable;

  public:
    static void InitItemTable();
    static void HintTable_Init();
    static void HintTable_Init_Item();
    static void HintTable_Init_Exclude_Overworld();
    static void HintTable_Init_Exclude_Dungeon();
    static Item& RetrieveItem(const RandomizerGet rgid);
    static Item& ItemFromGIID(const int giid);
    static std::array<Item, RG_MAX>&
    GetItemTable(); // is there a reason this is a function and not just an exposed table?
    static void InitLocationTable();
    static Location* GetLocation(RandomizerCheck locKey);
    static std::array<Rando::Location, RC_MAX>& GetLocationTable();
    static std::unordered_map<std::string, uint32_t>
    PopulateTranslationMap(const std::unordered_map<uint32_t, CustomMessage>& input);
    static std::unordered_map<std::string, uint32_t>
    PopulateTranslationMap(const std::unordered_map<uint32_t, RandomizerHintTextKey>& input);
    static std::multimap<std::tuple<s16, s16, s32>, RandomizerCheck> CheckFromActorMultimap;
    static std::vector<RandomizerCheck> GetAllDungeonLocations();
    static std::vector<RandomizerCheck> dungeonRewardLocations;
    static std::vector<RandomizerCheck> GetShopLocations();
    static std::vector<RandomizerCheck> GetScrubLocations();
    static std::vector<RandomizerCheck> GetMerchantLocations();
    static std::vector<RandomizerCheck> GetAdultTradeLocations();
    static std::vector<RandomizerCheck> GetGossipStoneLocations();
    static std::vector<RandomizerCheck> GetStaticHintLocations();
    static std::vector<RandomizerCheck> GetPondFishLocations();
    static std::vector<RandomizerCheck> GetOverworldFishLocations();
    static std::vector<RandomizerCheck> GetFountainFairyLocations();
    static std::vector<RandomizerCheck> GetStoneFairyLocations();
    static std::vector<RandomizerCheck> GetBeanFairyLocations();
    static std::vector<RandomizerCheck> GetSongFairyLocations();
    static void RegisterSongLocations();
    static void RegisterBeehiveLocations();
    static void RegisterCowLocations();
    static void RegisterFishLocations();
    static void RegisterFairyLocations();
    static void RegisterPotLocations();
    static void RegisterFreestandingLocations();
    static void RegisterSilverLocations();
    static void RegisterGrassLocations();
    static void RegisterCrateLocations();
    static void RegisterRockLocations();
    static void RegisterTreeLocations();
    static void RegisterSignLocations();
    static void RegisterWonderItemLocations();
    static void RegisterBeggarLocations();
    static void RegisterIcicleLocations();
    static void RegisterRedIceLocations();
    static void InitHashMaps();
    static std::array<std::pair<RandomizerCheck, RandomizerCheck>, 17> randomizerFishingPondFish;
    static std::unordered_map<int8_t, RandomizerCheck> randomizerGrottoFishMap;
    static std::vector<RandomizerHint> oldVerHintOrder;
    static uint16_t oldVerGossipStoneStart;
    static std::unordered_map<std::string, RandomizerCheck> locationNameToEnum;
    static std::unordered_map<std::string, RandomizerGet> itemNameToEnum;
    static std::unordered_map<uint32_t, CustomMessage> hintNames;
    static std::unordered_map<std::string, uint32_t> hintNameToEnum;
    static std::unordered_map<uint32_t, CustomMessage> hintTypeNames;
    static std::unordered_map<std::string, uint32_t> hintTypeNameToEnum;
    static std::unordered_map<RandomizerCheck, RandomizerHint> gossipStoneCheckToHint;
    static std::unordered_map<uint32_t, RandomizerHintTextKey> areaNames;
    static std::unordered_map<std::string, uint32_t> areaNameToEnum;
    static std::unordered_map<uint32_t, RandomizerHintTextKey> trialData;
    static std::unordered_map<std::string, uint32_t> trialNameToEnum;
    static std::unordered_map<std::string, RandomizerSettingKey> optionNameToEnum;
    static std::unordered_map<RandomizerHint, StaticHintInfo> staticHintInfoMap;
    static std::unordered_map<u32, RandomizerHint> stoneParamsToHint;
    static std::unordered_map<u32, RandomizerHint> grottoChestParamsToHint;
    static std::unordered_map<RandomizerGet, RandomizerCheckArea> silverToArea;
    static std::set<RandomizerGet> constantSilvers;
    static std::unordered_map<std::string, RandomizerTrick> trickToEnum;
    static std::array<HintText, RHT_MAX> hintTextTable;
    static std::vector<RandomizerGet> normalBottles;
    static std::vector<RandomizerGet> beanSouls;
    static std::vector<RandomizerGet> overworldKeys;
    static std::vector<RandomizerGet> silverRupees;
    static std::map<RandomizerGet, uint32_t> RandoGetToRandInf;
    static std::unordered_map<SceneID, std::set<RandomizerGet>> itemRestrictions;
    static std::set<RandomizerGet> restrictFW;
    static std::set<RandomizerGet> restrictSpells;
    static std::set<RandomizerGet> restrictTrade;
    static std::set<RandomizerGet> allowMasks;
    static std::set<RandomizerGet> allowBottleMaskTrade;

    StaticData();
    ~StaticData();
};
} // namespace Rando
