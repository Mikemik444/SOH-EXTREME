#pragma once

void SwitchAge();