#include "soh/Enhancements/game-interactor/GameInteractor.h"
#include "soh/ShipInit.hpp"

extern "C" {
#include "z64save.h"
extern SaveContext gSaveContext;
}

#define BOSS_DEFEAT_TIMESTAMP(actorID, timestamp)                                                     \
    COND_ID_HOOK(OnBossDefeat, actorID, true, [](void* refActor) {                                    \
        gSaveContext.ship.stats.itemTimestamp[timestamp] = static_cast<u32>(GAMEPLAYSTAT_TOTAL_TIME); \
    });

static void RegisterBossDefeatTimestamps() {
    BOSS_DEFEAT_TIMESTAMP(ACTOR_BOSS_GOMA, TIMESTAMP_DEFEAT_GOHMA);
    BOSS_DEFEAT_TIMESTAMP(ACTOR_BOSS_DODONGO, TIMESTAMP_DEFEAT_KING_DODONGO);
    BOSS_DEFEAT_TIMESTAMP(ACTOR_BOSS_VA, TIMESTAMP_DEFEAT_BARINADE);
    BOSS_DEFEAT_TIMESTAMP(ACTOR_BOSS_GANONDROF, TIMESTAMP_DEFEAT_PHANTOM_GANON);
    BOSS_DEFEAT_TIMESTAMP(ACTOR_BOSS_FD2, TIMESTAMP_DEFEAT_VOLVAGIA);
    BOSS_DEFEAT_TIMESTAMP(ACTOR_BOSS_MO, TIMESTAMP_DEFEAT_MORPHA);
    BOSS_DEFEAT_TIMESTAMP(ACTOR_BOSS_SST, TIMESTAMP_DEFEAT_BONGO_BONGO);
    BOSS_DEFEAT_TIMESTAMP(ACTOR_BOSS_TW, TIMESTAMP_DEFEAT_TWINROVA);
    BOSS_DEFEAT_TIMESTAMP(ACTOR_BOSS_GANON, TIMESTAMP_DEFEAT_GANONDORF);
    COND_ID_HOOK(OnBossDefeat, ACTOR_BOSS_GANON2, true, [](void* refActor) {
        gSaveContext.ship.stats.itemTimestamp[TIMESTAMP_DEFEAT_GANON] = static_cast<u32>(GAMEPLAYSTAT_TOTAL_TIME);
        gSaveContext.ship.stats.gameComplete = true;
    });
}

static RegisterShipInitFunc initFunc(RegisterBossDefeatTimestamps);
