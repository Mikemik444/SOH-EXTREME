#pragma once

#include "vanilla-behavior/GIVanillaBehavior.h"
#include "GameInteractor.h"

#ifdef __cplusplus
extern "C" {
#endif
// MARK: - Gameplay
void GameInteractor_ExecuteOnZTitleInit(void* gameState);
void GameInteractor_ExecuteOnZTitleUpdate(void* gameState);
void GameInteractor_ExecuteOnLoadGame(int32_t fileNum);
void GameInteractor_ExecuteOnExitGame(int32_t fileNum);
void GameInteractor_ExecuteOnGameStateMainStart();
void GameInteractor_ExecuteOnGameFrameUpdate();
void GameInteractor_ExecuteOnCameraState(PlayState* play);
void GameInteractor_ExecuteOnItemReceiveHooks(GetItemEntry itemEntry);
void GameInteractor_ExecuteOnEquipmentDelete(int16_t equipmentType, uint16_t equipValue);
void GameInteractor_ExecuteOnSaleEndHooks(GetItemEntry itemEntry);
void GameInteractor_ExecuteOnTransitionEndHooks(int16_t sceneNum);
void GameInteractor_ExecuteOnSceneInit(int16_t sceneNum);
void GameInteractor_ExecuteAfterSceneCommands(int16_t sceneNum);
void GameInteractor_ExecuteOnSceneFlagSet(int16_t sceneNum, int16_t flagType, int16_t flag);
void GameInteractor_ExecuteOnSceneFlagUnset(int16_t sceneNum, int16_t flagType, int16_t flag);
void GameInteractor_ExecuteOnFlagSet(int16_t flagType, int16_t flag);
void GameInteractor_ExecuteOnFlagUnset(int16_t flagType, int16_t flag);
void GameInteractor_ExecuteOnSceneSpawnActors();
void GameInteractor_ExecuteOnLinkSkeletonInit();
void GameInteractor_ExecuteOnLinkEquipmentChange();
void GameInteractor_ExecuteOnPlayerUpdate();
void GameInteractor_ExecuteOnSetDoAction(uint16_t action);
void GameInteractor_ExecuteOnPlayerSfx(u16 sfxId);
void GameInteractor_ExecuteOnOcarinaSongAction();
void GameInteractor_ExecuteOnWarpSongLeave();
void GameInteractor_ExecuteOnOcarinaNote(uint8_t note, float modulator, int8_t bend);
bool GameInteractor_ShouldActorInit(void* actor);
void GameInteractor_ExecuteOnActorInit(void* actor);
void GameInteractor_ExecuteOnActorSpawn(void* actor);
bool GameInteractor_ShouldActorUpdate(void* actor);
void GameInteractor_ExecuteOnActorUpdate(void* actor);
void GameInteractor_ExecuteOnActorKill(void* actor);
bool GameInteractor_ShouldActorDestroy(void* actor);
void GameInteractor_ExecuteOnActorDestroy(void* actor);
void GameInteractor_ExecuteOnEnemyDefeat(void* actor);
void GameInteractor_ExecuteOnBossDefeat(void* actor);
void GameInteractor_ExecuteOnTimestamp(u8 item);
void GameInteractor_ExecuteOnPlayerBonk();
void GameInteractor_ExecuteOnPlayerSetModels(Player* player, u8 modelGroup);
void GameInteractor_ExecuteOnPlayerHealthChange(int16_t amount);
void GameInteractor_ExecuteOnPlayerBottleUpdate(int16_t contents);
void GameInteractor_ExecuteOnPlayerHoldUpShield();
void GameInteractor_ExecuteOnPlayerFirstPersonControl(Player* player);
void GameInteractor_ExecuteOnPlayerShieldControl(float* sp50, float* sp54);
void GameInteractor_ExecuteOnPlayerProcessStick();
void GameInteractor_ExecuteOnShopSlotChangeHooks(uint8_t cursorIndex, int16_t price);
void GameInteractor_ExecuteOnDungeonKeyUsedHooks(uint16_t mapIndex);
void GameInteractor_ExecuteOnPlayDestroy();
void GameInteractor_ExecuteOnPlayDrawBegin();
void GameInteractor_ExecuteOnPlayDrawEnd();
bool GameInteractor_Should(GIVanillaBehavior flag, uint32_t result, ...);

// MARK: -  Save Files
void GameInteractor_ExecuteOnSaveFile(int32_t fileNum, int32_t sectionID);
void GameInteractor_ExecuteOnLoadFile(int32_t fileNum);
void GameInteractor_ExecuteOnDeleteFile(int32_t fileNum);

// MARK: - Dialog
void GameInteractor_ExecuteOnDialogMessage();
void GameInteractor_ExecuteOnPresentTitleCard();
void GameInteractor_ExecuteOnInterfaceUpdate();
void GameInteractor_ExecuteOnKaleidoscopeUpdate(int16_t inDungeonScene);
void GameInteractor_ExecuteOnMinimapDrawCompassIcons();

// MARK: - Main Menu
void GameInteractor_ExecuteOnPresentFileSelect();
void GameInteractor_ExecuteOnUpdateFileSelectSelection(uint16_t optionIndex);
void GameInteractor_ExecuteOnUpdateFileSelectConfirmationSelection(uint16_t optionIndex);
void GameInteractor_ExecuteOnUpdateFileCopySelection(uint16_t optionIndex);
void GameInteractor_ExecuteOnUpdateFileCopyConfirmationSelection(uint16_t optionIndex);
void GameInteractor_ExecuteOnUpdateFileEraseSelection(uint16_t optionIndex);
void GameInteractor_ExecuteOnUpdateFileEraseConfirmationSelection(uint16_t optionIndex);
void GameInteractor_ExecuteOnUpdateFileAudioSelection(uint8_t optionIndex);
void GameInteractor_ExecuteOnUpdateFileTargetSelection(uint8_t optionIndex);
void GameInteractor_ExecuteOnUpdateFileLanguageSelection(uint8_t optionIndex);
void GameInteractor_ExecuteOnUpdateFileQuestSelection(uint8_t questIndex);
void GameInteractor_ExecuteOnUpdateFileBossRushOptionSelection(uint8_t optionIndex, uint8_t optionValue);
void GameInteractor_ExecuteOnUpdateFileRandomizerOptionSelection(uint8_t optionIndex);
void GameInteractor_ExecuteOnUpdateFileNameSelection(int16_t charCode);
void GameInteractor_ExecuteOnFileChooseMain(void* gameState);

// MARK: - Game
void GameInteractor_ExecuteOnSetGameLanguage();

// MARK: - System
void GameInteractor_RegisterOnAssetAltChange(void (*fn)(void));

// Mark: - Pause Menu
void GameInteractor_ExecuteOnKaleidoUpdate();

// MARK: - Messages
void GameInteractor_ExecuteOnOpenText(uint16_t* textId, bool* loadFromMessageTable);

// Mark: - Audio
void GameInteractor_ExecuteOnSeqPlayerInit(int32_t playerIdx, int32_t seqId);

// MARK: - Rando
void GameInteractor_ExecuteOnRandoEntranceDiscovered(u16 entranceIndex, u8 isReversedEntrance);

#ifdef __cplusplus
}
#endif
